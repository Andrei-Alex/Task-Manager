create function numeric(money) returns numeric
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_numeric$$;

comment on function numeric(real) is 'convert float4 to numeric';

alter function numeric(real) owner to postgres;

