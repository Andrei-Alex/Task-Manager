create function arraycontsel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$arraycontsel$$;

comment on function arraycontsel(internal, oid, internal, integer) is 'restriction selectivity for array-containment operators';

alter function arraycontsel(internal, oid, internal, integer) owner to postgres;

