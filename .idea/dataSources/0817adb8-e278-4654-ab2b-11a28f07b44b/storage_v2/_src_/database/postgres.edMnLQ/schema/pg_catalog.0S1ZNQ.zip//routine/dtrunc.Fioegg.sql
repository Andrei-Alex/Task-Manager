create function dtrunc(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dtrunc$$;

comment on function dtrunc(double precision) is 'truncate to integer';

alter function dtrunc(double precision) owner to postgres;

