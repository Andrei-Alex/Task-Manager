create function bittypmodout(integer) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bittypmodout$$;

comment on function bittypmodout(integer) is 'I/O typmod';

alter function bittypmodout(integer) owner to postgres;

