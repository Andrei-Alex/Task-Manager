create function acos(double precision) returns double precision
    language internal
as
$$dacos$$;

comment on function acos(float8) is 'arccosine';

