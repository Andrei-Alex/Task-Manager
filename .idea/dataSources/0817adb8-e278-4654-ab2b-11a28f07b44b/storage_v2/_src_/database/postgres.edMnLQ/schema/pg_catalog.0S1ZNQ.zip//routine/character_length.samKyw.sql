create function character_length(text) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$textlen$$;

comment on function character_length(char) is 'character length';

alter function character_length(char) owner to postgres;

