create function substring(text, integer, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$text_substr$$;

comment on function substring(bit, integer, integer) is 'extract portion of bitstring';

alter function substring(bit, integer, integer) owner to postgres;

