create function bpchartypmodout(integer) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bpchartypmodout$$;

comment on function bpchartypmodout(integer) is 'I/O typmod';

alter function bpchartypmodout(integer) owner to postgres;

