create function hashoidextended(oid, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashoidextended$$;

comment on function hashoidextended(oid, bigint) is 'hash';

alter function hashoidextended(oid, bigint) owner to postgres;

