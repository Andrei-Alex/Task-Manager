create function float8_avg(double precision[]) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float8_avg$$;

comment on function float8_avg(double precision[]) is 'aggregate final function';

alter function float8_avg(double precision[]) owner to postgres;

