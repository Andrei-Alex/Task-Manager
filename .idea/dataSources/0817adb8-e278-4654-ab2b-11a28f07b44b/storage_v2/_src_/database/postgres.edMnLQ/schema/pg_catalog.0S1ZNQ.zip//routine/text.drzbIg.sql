create function text(character) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$rtrim1$$;

comment on function text("char") is 'convert char to text';

alter function text("char") owner to postgres;

