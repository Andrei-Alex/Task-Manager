create function brin_bloom_consistent(internal, internal, internal, integer) returns boolean
    language internal
as
$$brin_bloom_consistent$$;

comment on function brin_bloom_consistent(internal, internal, internal, int4) is 'BRIN bloom support';

