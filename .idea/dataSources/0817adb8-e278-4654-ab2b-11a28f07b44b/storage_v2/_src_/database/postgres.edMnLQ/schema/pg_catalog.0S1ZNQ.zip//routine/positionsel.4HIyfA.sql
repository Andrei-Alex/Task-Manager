create function positionsel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$positionsel$$;

comment on function positionsel(internal, oid, internal, integer) is 'restriction selectivity for position-comparison operators';

alter function positionsel(internal, oid, internal, integer) owner to postgres;

