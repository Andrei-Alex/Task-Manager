create function asinh(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dasinh$$;

comment on function asinh(double precision) is 'inverse hyperbolic sine';

alter function asinh(double precision) owner to postgres;

