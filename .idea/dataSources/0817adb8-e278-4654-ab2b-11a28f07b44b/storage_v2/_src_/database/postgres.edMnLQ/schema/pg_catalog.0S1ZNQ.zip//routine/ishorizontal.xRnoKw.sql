create function ishorizontal(lseg) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$lseg_horizontal$$;

comment on function ishorizontal(line, point) is 'horizontal';

alter function ishorizontal(line, point) owner to postgres;

