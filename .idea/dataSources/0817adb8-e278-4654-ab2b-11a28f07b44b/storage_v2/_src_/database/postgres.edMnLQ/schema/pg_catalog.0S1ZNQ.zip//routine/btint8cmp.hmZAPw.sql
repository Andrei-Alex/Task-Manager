create function btint8cmp(bigint, bigint) returns integer
    language internal
as
$$btint8cmp$$;

comment on function btint8cmp(int8, int8) is 'less-equal-greater';

