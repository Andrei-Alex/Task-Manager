create function cash_div_flt4(money, real) returns money
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_div_flt4$$;

comment on function cash_div_flt4(money, real) is 'implementation of / operator';

alter function cash_div_flt4(money, real) owner to postgres;

