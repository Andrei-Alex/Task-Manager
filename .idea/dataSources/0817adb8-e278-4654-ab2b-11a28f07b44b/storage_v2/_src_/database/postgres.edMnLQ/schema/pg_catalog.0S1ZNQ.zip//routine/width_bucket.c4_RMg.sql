create function width_bucket(anycompatible, anycompatiblearray) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$width_bucket_array$$;

comment on function width_bucket(numeric, numeric, numeric, integer) is 'bucket number of operand in equal-width histogram';

alter function width_bucket(numeric, numeric, numeric, integer) owner to postgres;

