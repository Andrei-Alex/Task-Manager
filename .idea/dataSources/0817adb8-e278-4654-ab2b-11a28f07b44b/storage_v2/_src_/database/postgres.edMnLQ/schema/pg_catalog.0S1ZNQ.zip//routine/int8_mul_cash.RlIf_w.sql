create function int8_mul_cash(bigint, money) returns money
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int8_mul_cash$$;

comment on function int8_mul_cash(bigint, money) is 'implementation of * operator';

alter function int8_mul_cash(bigint, money) owner to postgres;

