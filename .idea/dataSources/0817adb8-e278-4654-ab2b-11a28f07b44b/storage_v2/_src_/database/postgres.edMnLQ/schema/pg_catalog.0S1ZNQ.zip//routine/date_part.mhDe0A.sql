create function date_part(text, timestamp with time zone) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_part$$;

comment on function date_part(text, timestamp) is 'extract field from timestamp';

alter function date_part(text, timestamp) owner to postgres;

