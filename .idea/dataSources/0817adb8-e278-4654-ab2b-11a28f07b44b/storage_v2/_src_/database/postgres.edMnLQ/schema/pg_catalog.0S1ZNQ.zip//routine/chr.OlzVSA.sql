create function chr(integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$chr$$;

comment on function chr(integer) is 'convert int4 to char';

alter function chr(integer) owner to postgres;

