create function date_bin(interval, timestamp without time zone, timestamp without time zone) returns timestamp without time zone
    language internal
as
$$timestamp_bin$$;

comment on function date_bin(interval, timestamptz, timestamptz) is 'bin timestamp with time zone into specified interval';

