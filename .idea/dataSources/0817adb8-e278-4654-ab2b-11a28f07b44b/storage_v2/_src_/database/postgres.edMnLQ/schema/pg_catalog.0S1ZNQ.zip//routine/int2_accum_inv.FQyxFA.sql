create function int2_accum_inv(internal, smallint) returns internal
    immutable
    parallel safe
    cost 1
    language internal
as
$$int2_accum_inv$$;

comment on function int2_accum_inv(internal, smallint) is 'aggregate transition function';

alter function int2_accum_inv(internal, smallint) owner to postgres;

