create function trunc(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dtrunc$$;

comment on function trunc(numeric, integer) is 'value truncated to ''scale''';

alter function trunc(numeric, integer) owner to postgres;

