create function pg_stat_get_backend_activity(integer) returns text
    stable
    strict
    parallel restricted
    cost 1
    language internal
as
$$pg_stat_get_backend_activity$$;

comment on function pg_stat_get_backend_activity(integer) is 'statistics: current query of backend';

alter function pg_stat_get_backend_activity(integer) owner to postgres;

