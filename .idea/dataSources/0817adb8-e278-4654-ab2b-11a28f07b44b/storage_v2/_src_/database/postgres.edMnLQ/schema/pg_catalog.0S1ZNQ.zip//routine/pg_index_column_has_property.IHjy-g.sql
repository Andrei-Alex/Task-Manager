create function pg_index_column_has_property(regclass, integer, text) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_index_column_has_property$$;

comment on function pg_index_column_has_property(regclass, integer, text) is 'test property of an index column';

alter function pg_index_column_has_property(regclass, integer, text) owner to postgres;

