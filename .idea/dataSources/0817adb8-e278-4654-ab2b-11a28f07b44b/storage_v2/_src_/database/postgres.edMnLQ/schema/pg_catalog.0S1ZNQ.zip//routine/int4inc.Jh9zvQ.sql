create function int4inc(integer) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int4inc$$;

comment on function int4inc(integer) is 'increment';

alter function int4inc(integer) owner to postgres;

