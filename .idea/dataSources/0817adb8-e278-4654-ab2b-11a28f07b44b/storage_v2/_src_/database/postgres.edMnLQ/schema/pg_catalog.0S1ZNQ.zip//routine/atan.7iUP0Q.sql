create function atan(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$datan$$;

comment on function atan(double precision) is 'arctangent';

alter function atan(double precision) owner to postgres;

