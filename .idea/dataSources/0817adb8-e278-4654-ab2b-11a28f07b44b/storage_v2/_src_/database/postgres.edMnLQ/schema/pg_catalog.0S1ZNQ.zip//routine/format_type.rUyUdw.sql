create function format_type(oid, integer) returns text
    stable
    parallel safe
    cost 1
    language internal
as
$$format_type$$;

comment on function format_type(oid, integer) is 'format a type oid and atttypmod to canonical SQL';

alter function format_type(oid, integer) owner to postgres;

