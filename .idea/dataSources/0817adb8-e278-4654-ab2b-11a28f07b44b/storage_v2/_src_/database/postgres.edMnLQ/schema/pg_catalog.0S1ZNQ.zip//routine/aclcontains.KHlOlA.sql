create function aclcontains(aclitem[], aclitem) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$aclcontains$$;

comment on function aclcontains(aclitem[], aclitem) is 'contains';

alter function aclcontains(aclitem[], aclitem) owner to postgres;

