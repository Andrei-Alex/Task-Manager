create function varcharrecv(internal, oid, integer) returns character varying
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$varcharrecv$$;

comment on function varcharrecv(internal, oid, integer) is 'I/O';

alter function varcharrecv(internal, oid, integer) owner to postgres;

