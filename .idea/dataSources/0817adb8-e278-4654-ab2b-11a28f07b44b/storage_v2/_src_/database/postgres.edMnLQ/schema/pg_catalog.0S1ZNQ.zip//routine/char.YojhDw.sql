create function char(integer) returns "char"
    language internal
as
$$i4tochar$$;

comment on function char(text) is 'convert text to char';

