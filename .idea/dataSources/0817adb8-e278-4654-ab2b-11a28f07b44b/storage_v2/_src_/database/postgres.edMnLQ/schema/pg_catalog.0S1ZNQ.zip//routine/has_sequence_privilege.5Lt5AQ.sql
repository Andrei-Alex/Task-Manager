create function has_sequence_privilege(name, text, text) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$has_sequence_privilege_name_name$$;

comment on function has_sequence_privilege(text, text, text) is 'current user privilege on sequence by seq name';

alter function has_sequence_privilege(text, text, text) owner to postgres;

