create function prefixsel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$prefixsel$$;

comment on function prefixsel(internal, oid, internal, integer) is 'restriction selectivity of exact prefix';

alter function prefixsel(internal, oid, internal, integer) owner to postgres;

