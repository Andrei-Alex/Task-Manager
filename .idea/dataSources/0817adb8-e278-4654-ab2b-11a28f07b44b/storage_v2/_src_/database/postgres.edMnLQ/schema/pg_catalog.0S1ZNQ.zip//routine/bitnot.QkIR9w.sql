create function bitnot(bit) returns bit
    language internal
as
$$bitnot$$;

comment on function bitnot(bit) is 'implementation of ~ operator';

