create function money(bigint) returns money
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$int8_cash$$;

comment on function money(integer) is 'convert int4 to money';

alter function money(integer) owner to postgres;

