create function convert(bytea, name, name) returns bytea
    language internal
as
$$pg_convert$$;

comment on function convert(bytea, name, name) is 'convert string with specified encoding names';

