create function hashoidvectorextended(oidvector, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashoidvectorextended$$;

comment on function hashoidvectorextended(oidvector, bigint) is 'hash';

alter function hashoidvectorextended(oidvector, bigint) owner to postgres;

