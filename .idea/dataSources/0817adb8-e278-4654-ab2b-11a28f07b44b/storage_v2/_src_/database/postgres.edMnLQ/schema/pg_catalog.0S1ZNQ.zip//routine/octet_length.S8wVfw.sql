create function octet_length(bytea) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$byteaoctetlen$$;

comment on function octet_length(char) is 'octet length';

alter function octet_length(char) owner to postgres;

