create function set_masklen(cidr, integer) returns cidr
    language internal
as
$$cidr_set_masklen$$;

comment on function set_masklen(inet, int4) is 'change netmask of inet';

