create function trim_array(anyarray, integer) returns anyarray
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$trim_array$$;

comment on function trim_array(anyarray, integer) is 'remove last N elements of array';

alter function trim_array(anyarray, integer) owner to postgres;

