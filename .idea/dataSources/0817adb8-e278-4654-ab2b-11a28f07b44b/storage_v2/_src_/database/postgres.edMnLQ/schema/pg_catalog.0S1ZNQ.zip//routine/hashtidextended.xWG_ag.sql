create function hashtidextended(tid, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashtidextended$$;

comment on function hashtidextended(tid, bigint) is 'hash';

alter function hashtidextended(tid, bigint) owner to postgres;

