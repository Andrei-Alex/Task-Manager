create function text(character) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$rtrim1$$;

comment on function text(boolean) is 'convert boolean to text';

alter function text(boolean) owner to postgres;

