create function float8up(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float8up$$;

comment on function float8up(double precision) is 'implementation of + operator';

alter function float8up(double precision) owner to postgres;

