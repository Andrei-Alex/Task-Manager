create function inetmi_int8(inet, bigint) returns inet
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$inetmi_int8$$;

comment on function inetmi_int8(inet, bigint) is 'implementation of - operator';

alter function inetmi_int8(inet, bigint) owner to postgres;

