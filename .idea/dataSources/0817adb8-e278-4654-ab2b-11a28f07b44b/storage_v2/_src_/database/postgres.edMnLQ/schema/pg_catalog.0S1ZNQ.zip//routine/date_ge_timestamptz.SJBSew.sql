create function date_ge_timestamptz(date, timestamp with time zone) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$date_ge_timestamptz$$;

comment on function date_ge_timestamptz(date, timestamp with time zone) is 'implementation of >= operator';

alter function date_ge_timestamptz(date, timestamp with time zone) owner to postgres;

