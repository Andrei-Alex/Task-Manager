create function record_in(cstring, oid, integer) returns record
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$record_in$$;

comment on function record_in(cstring, oid, integer) is 'I/O';

alter function record_in(cstring, oid, integer) owner to postgres;

