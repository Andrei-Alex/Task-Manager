create function brin_bloom_summary_send(pg_brin_bloom_summary) returns bytea
    language internal
as
$$brin_bloom_summary_send$$;

comment on function brin_bloom_summary_send(pg_brin_bloom_summary) is 'I/O';

