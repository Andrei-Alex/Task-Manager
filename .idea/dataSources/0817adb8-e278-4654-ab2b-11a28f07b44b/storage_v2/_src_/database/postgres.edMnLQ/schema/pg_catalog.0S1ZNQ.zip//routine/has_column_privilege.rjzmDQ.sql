create function has_column_privilege(name, text, text, text) returns boolean
    language internal
as
$$has_column_privilege_name_name_name$$;

comment on function has_column_privilege(oid, text, int2, text) is 'user privilege on column by user oid, rel name, col attnum';

