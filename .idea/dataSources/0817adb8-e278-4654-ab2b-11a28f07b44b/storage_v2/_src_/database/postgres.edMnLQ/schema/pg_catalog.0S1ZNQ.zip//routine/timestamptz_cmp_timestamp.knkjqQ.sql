create function timestamptz_cmp_timestamp(timestamp with time zone, timestamp without time zone) returns integer
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_cmp_timestamp$$;

comment on function timestamptz_cmp_timestamp(timestamp with time zone, timestamp) is 'less-equal-greater';

alter function timestamptz_cmp_timestamp(timestamp with time zone, timestamp) owner to postgres;

