create function bpcharout(character) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bpcharout$$;

comment on function bpcharout(char) is 'I/O';

alter function bpcharout(char) owner to postgres;

