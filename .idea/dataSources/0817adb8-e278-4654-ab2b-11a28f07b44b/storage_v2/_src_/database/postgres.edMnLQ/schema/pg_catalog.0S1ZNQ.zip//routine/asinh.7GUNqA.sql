create function asinh(double precision) returns double precision
    language internal
as
$$dasinh$$;

comment on function asinh(float8) is 'inverse hyperbolic sine';

