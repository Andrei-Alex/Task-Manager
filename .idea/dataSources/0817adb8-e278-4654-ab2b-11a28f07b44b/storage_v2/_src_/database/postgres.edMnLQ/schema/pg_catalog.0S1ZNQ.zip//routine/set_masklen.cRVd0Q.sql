create function set_masklen(cidr, integer) returns cidr
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cidr_set_masklen$$;

comment on function set_masklen(cidr, integer) is 'change netmask of cidr';

alter function set_masklen(cidr, integer) owner to postgres;

