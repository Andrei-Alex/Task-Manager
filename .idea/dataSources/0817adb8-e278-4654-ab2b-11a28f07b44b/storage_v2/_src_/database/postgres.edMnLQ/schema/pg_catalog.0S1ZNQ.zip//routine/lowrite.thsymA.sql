create function lowrite(integer, bytea) returns integer
    strict
    cost 1
    language internal
as
$$be_lowrite$$;

comment on function lowrite(integer, bytea) is 'large object write';

alter function lowrite(integer, bytea) owner to postgres;

