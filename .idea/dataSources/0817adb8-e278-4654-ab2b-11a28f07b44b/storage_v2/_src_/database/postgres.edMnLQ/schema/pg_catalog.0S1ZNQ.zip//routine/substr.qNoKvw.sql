create function substr(text, integer, integer) returns text
    language internal
as
$$text_substr$$;

comment on function substr(text, int4) is 'extract portion of string';

