create function float8send(double precision) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float8send$$;

comment on function float8send(double precision) is 'I/O';

alter function float8send(double precision) owner to postgres;

