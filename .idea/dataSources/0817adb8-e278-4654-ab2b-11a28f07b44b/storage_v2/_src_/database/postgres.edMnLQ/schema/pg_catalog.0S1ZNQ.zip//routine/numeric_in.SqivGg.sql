create function numeric_in(cstring, oid, integer) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$numeric_in$$;

comment on function numeric_in(cstring, oid, integer) is 'I/O';

alter function numeric_in(cstring, oid, integer) owner to postgres;

