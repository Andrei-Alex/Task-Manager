create function bpcharicnlike(character, text) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$texticnlike$$;

comment on function bpcharicnlike(char, text) is 'implementation of !~~* operator';

alter function bpcharicnlike(char, text) owner to postgres;

