create function cidr_recv(internal) returns cidr
    language internal
as
$$cidr_recv$$;

comment on function cidr_recv(internal) is 'I/O';

