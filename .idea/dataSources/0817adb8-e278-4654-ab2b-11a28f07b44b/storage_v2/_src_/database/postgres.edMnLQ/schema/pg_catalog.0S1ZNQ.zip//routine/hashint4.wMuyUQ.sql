create function hashint4(integer) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashint4$$;

comment on function hashint4(integer) is 'hash';

alter function hashint4(integer) owner to postgres;

