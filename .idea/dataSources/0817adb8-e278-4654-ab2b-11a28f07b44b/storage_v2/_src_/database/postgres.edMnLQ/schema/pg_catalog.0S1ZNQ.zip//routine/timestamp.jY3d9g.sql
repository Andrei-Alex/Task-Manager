create function timestamp(timestamp without time zone, integer) returns timestamp without time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamp_scale$$;

comment on function timestamp(timestamp, integer) is 'adjust timestamp precision';

alter function timestamp(timestamp, integer) owner to postgres;

