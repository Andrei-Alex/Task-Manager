create function extract(text, timestamp with time zone) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$extract_timestamptz$$;

comment on function extract(text, date) is 'extract field from date';

alter function extract(text, date) owner to postgres;

