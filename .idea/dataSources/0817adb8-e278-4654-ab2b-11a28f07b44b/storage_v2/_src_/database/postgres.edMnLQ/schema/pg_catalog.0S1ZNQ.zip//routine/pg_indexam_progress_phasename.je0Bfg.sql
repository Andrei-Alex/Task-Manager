create function pg_indexam_progress_phasename(oid, bigint) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_indexam_progress_phasename$$;

comment on function pg_indexam_progress_phasename(oid, bigint) is 'return name of given index build phase';

alter function pg_indexam_progress_phasename(oid, bigint) owner to postgres;

