create function aclitemout(aclitem) returns cstring
    language internal
as
$$aclitemout$$;

comment on function aclitemout(aclitem) is 'I/O';

