create function lo_tell(integer) returns integer
    strict
    cost 1
    language internal
as
$$be_lo_tell$$;

comment on function lo_tell(integer) is 'large object position';

alter function lo_tell(integer) owner to postgres;

