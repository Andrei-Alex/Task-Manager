create function bpcharicregexne(character, text) returns boolean
    language internal
as
$$texticregexne$$;

comment on function bpcharicregexne(bpchar, text) is 'implementation of !~* operator';

