create function charle("char", "char") returns boolean
    language internal
as
$$charle$$;

comment on function charle("char", "char") is 'implementation of <= operator';

