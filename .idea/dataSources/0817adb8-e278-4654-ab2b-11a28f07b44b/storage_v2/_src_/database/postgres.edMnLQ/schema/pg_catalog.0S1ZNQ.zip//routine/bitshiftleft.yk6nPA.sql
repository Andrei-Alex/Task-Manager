create function bitshiftleft(bit, integer) returns bit
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bitshiftleft$$;

comment on function bitshiftleft(bit, integer) is 'implementation of << operator';

alter function bitshiftleft(bit, integer) owner to postgres;

