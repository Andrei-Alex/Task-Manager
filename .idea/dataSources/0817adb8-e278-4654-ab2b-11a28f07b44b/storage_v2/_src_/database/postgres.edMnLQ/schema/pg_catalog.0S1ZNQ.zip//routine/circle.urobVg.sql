create function circle(box) returns circle
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$box_circle$$;

comment on function circle(point, double precision) is 'convert point and radius to circle';

alter function circle(point, double precision) owner to postgres;

