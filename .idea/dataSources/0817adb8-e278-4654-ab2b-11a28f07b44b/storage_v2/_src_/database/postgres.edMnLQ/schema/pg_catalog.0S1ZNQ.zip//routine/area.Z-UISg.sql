create function area(path) returns double precision
    language internal
as
$$path_area$$;

comment on function area(box) is 'box area';

