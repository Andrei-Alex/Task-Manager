create function cash_words(money) returns text
    language internal
as
$$cash_words$$;

comment on function cash_words(money) is 'output money amount as words';

