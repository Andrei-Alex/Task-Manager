create function hash_aclitem_extended(aclitem, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hash_aclitem_extended$$;

comment on function hash_aclitem_extended(aclitem, bigint) is 'hash';

alter function hash_aclitem_extended(aclitem, bigint) owner to postgres;

