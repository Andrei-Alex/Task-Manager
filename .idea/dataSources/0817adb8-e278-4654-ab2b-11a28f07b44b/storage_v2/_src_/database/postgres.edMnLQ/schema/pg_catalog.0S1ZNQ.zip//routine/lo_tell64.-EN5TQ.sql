create function lo_tell64(integer) returns bigint
    strict
    cost 1
    language internal
as
$$be_lo_tell64$$;

comment on function lo_tell64(integer) is 'large object position (64 bit)';

alter function lo_tell64(integer) owner to postgres;

