create function "RI_FKey_noaction_del"() returns trigger
    language internal
as
$$RI_FKey_noaction_del$$;

comment on function "RI_FKey_noaction_del"() is 'referential integrity ON DELETE NO ACTION';

