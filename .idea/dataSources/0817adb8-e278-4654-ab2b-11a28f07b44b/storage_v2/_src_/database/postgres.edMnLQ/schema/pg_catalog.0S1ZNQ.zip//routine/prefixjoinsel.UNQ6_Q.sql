create function prefixjoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$prefixjoinsel$$;

comment on function prefixjoinsel(internal, oid, internal, smallint, internal) is 'join selectivity of exact prefix';

alter function prefixjoinsel(internal, oid, internal, smallint, internal) owner to postgres;

