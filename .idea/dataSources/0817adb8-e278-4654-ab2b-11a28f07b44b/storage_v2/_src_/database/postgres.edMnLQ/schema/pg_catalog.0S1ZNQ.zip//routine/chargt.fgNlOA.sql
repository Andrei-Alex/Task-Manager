create function chargt("char", "char") returns boolean
    language internal
as
$$chargt$$;

comment on function chargt("char", "char") is 'implementation of > operator';

