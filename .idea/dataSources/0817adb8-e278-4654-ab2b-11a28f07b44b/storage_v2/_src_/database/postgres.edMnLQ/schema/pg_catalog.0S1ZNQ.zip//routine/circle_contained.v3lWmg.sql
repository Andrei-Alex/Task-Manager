create function circle_contained(circle, circle) returns boolean
    language internal
as
$$circle_contained$$;

comment on function circle_contained(circle, circle) is 'implementation of <@ operator';

