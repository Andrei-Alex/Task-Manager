create function array_position(anycompatiblearray, anycompatible) returns integer
    language internal
as
$$array_position$$;

comment on function array_position(anycompatiblearray, anycompatible) is 'returns an offset of value in array';

