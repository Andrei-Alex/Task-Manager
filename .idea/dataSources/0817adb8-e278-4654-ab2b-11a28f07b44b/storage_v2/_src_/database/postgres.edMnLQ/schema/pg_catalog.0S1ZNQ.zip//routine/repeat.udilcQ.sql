create function repeat(text, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$repeat$$;

comment on function repeat(text, integer) is 'replicate string n times';

alter function repeat(text, integer) owner to postgres;

