create function brin_desummarize_range(regclass, bigint) returns void
    strict
    cost 1
    language internal
as
$$brin_desummarize_range$$;

comment on function brin_desummarize_range(regclass, bigint) is 'brin: desummarize page range';

alter function brin_desummarize_range(regclass, bigint) owner to postgres;

