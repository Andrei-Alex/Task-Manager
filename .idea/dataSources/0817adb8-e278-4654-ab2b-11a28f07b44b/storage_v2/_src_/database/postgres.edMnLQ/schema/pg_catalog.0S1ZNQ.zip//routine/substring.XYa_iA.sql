create function substring(text, integer, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$text_substr$$;

comment on function substring(bytea, integer, integer) is 'extract portion of string';

alter function substring(bytea, integer, integer) owner to postgres;

