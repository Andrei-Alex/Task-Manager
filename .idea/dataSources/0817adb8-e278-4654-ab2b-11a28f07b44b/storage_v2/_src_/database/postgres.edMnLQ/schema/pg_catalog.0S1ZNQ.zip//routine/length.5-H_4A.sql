create function length(text) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$textlen$$;

comment on function length(path, name) is 'sum of path segments';

alter function length(path, name) owner to postgres;

