create function bittypmodin(cstring[]) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bittypmodin$$;

comment on function bittypmodin(cstring[]) is 'I/O typmod';

alter function bittypmodin(cstring[]) owner to postgres;

