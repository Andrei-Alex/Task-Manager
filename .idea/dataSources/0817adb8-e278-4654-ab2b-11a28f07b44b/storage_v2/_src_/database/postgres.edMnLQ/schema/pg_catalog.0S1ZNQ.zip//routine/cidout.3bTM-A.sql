create function cidout(cid) returns cstring
    language internal
as
$$cidout$$;

comment on function cidout(cid) is 'I/O';

