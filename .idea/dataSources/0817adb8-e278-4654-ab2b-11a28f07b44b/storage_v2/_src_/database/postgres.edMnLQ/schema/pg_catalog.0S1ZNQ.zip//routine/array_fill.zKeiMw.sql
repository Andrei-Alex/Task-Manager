create function array_fill(anyelement, integer[]) returns anyarray
    immutable
    parallel safe
    cost 1
    language internal
as
$$array_fill$$;

comment on function array_fill(anyelement, integer[]) is 'array constructor with value';

alter function array_fill(anyelement, integer[]) owner to postgres;

