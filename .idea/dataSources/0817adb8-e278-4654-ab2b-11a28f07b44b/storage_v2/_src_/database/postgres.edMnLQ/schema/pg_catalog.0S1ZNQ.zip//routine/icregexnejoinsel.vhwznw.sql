create function icregexnejoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$icregexnejoinsel$$;

comment on function icregexnejoinsel(internal, oid, internal, smallint, internal) is 'join selectivity of case-insensitive regex non-match';

alter function icregexnejoinsel(internal, oid, internal, smallint, internal) owner to postgres;

