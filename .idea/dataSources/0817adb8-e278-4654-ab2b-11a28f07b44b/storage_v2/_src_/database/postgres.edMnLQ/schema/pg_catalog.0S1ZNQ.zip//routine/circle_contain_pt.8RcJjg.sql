create function circle_contain_pt(circle, point) returns boolean
    language internal
as
$$circle_contain_pt$$;

comment on function circle_contain_pt(circle, point) is 'implementation of @> operator';

