create function log10(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dlog10$$;

comment on function log10(double precision) is 'base 10 logarithm';

alter function log10(double precision) owner to postgres;

