create function numeric(money) returns numeric
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_numeric$$;

comment on function numeric(double precision) is 'convert float8 to numeric';

alter function numeric(double precision) owner to postgres;

