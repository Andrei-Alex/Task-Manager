create function date_trunc(text, timestamp with time zone) returns timestamp with time zone
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_trunc$$;

comment on function date_trunc(text, timestamp with time zone, text) is 'truncate timestamp with time zone to specified units in specified time zone';

alter function date_trunc(text, timestamp with time zone, text) owner to postgres;

