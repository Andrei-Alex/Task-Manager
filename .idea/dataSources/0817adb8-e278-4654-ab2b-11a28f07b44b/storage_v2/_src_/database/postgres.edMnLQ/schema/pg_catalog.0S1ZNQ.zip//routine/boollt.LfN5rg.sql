create function boollt(boolean, boolean) returns boolean
    language internal
as
$$boollt$$;

comment on function boollt(bool, bool) is 'implementation of < operator';

