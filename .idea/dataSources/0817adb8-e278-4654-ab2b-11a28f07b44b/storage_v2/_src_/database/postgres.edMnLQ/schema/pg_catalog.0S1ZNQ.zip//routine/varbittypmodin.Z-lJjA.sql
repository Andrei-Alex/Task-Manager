create function varbittypmodin(cstring[]) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$varbittypmodin$$;

comment on function varbittypmodin(cstring[]) is 'I/O typmod';

alter function varbittypmodin(cstring[]) owner to postgres;

