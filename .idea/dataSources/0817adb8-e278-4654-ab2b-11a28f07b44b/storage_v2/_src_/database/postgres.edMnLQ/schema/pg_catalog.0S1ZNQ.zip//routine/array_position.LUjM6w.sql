create function array_position(anycompatiblearray, anycompatible) returns integer
    immutable
    parallel safe
    cost 1
    language internal
as
$$array_position$$;

comment on function array_position(anycompatiblearray, anycompatible, integer) is 'returns an offset of value in array with start index';

alter function array_position(anycompatiblearray, anycompatible, integer) owner to postgres;

