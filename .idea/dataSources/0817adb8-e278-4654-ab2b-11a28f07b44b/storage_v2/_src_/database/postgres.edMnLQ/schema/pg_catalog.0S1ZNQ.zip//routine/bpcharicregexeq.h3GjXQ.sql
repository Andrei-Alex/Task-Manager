create function bpcharicregexeq(character, text) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$texticregexeq$$;

comment on function bpcharicregexeq(char, text) is 'implementation of ~* operator';

alter function bpcharicregexeq(char, text) owner to postgres;

