create function float8um(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float8um$$;

comment on function float8um(double precision) is 'implementation of - operator';

alter function float8um(double precision) owner to postgres;

