create function varbit_send(bit varying) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$varbit_send$$;

comment on function varbit_send(bit varying) is 'I/O';

alter function varbit_send(bit varying) owner to postgres;

