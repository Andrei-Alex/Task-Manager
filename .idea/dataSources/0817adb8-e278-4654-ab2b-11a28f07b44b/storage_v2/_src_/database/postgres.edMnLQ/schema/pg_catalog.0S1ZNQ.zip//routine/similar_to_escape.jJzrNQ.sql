create function similar_to_escape(text) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$similar_to_escape_1$$;

comment on function similar_to_escape(text, text) is 'convert SQL regexp pattern to POSIX style';

alter function similar_to_escape(text, text) owner to postgres;

