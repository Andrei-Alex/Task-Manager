create function close_pl(point, line) returns point
    language internal
as
$$close_pl$$;

comment on function close_pl(point, line) is 'implementation of ## operator';

