create function has_column_privilege(name, text, text, text) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$has_column_privilege_name_name_name$$;

comment on function has_column_privilege(oid, oid, smallint, text) is 'user privilege on column by user oid, rel oid, col attnum';

alter function has_column_privilege(oid, oid, smallint, text) owner to postgres;

