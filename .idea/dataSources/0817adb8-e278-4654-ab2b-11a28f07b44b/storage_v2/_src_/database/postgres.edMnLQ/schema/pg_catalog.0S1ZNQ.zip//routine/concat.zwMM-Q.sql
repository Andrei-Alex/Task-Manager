create function concat(VARIADIC "any") returns text
    language internal
as
$$text_concat$$;

comment on function concat(any) is 'concatenate values';

