create function bytealt(bytea, bytea) returns boolean
    language internal
as
$$bytealt$$;

comment on function bytealt(bytea, bytea) is 'implementation of < operator';

