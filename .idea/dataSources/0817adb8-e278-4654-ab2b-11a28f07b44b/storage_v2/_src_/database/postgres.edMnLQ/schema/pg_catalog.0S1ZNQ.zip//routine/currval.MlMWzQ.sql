create function currval(regclass) returns bigint
    language internal
as
$$currval_oid$$;

comment on function currval(regclass) is 'sequence current value';

