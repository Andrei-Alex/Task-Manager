create function substring(text, integer, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$text_substr$$;

comment on function substring(bytea, integer, int4) is 'extract portion of string';

alter function substring(bytea, integer, int4) owner to postgres;

