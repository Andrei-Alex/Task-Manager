create function time_recv(internal, oid, integer) returns time without time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$time_recv$$;

comment on function time_recv(internal, oid, integer) is 'I/O';

alter function time_recv(internal, oid, integer) owner to postgres;

