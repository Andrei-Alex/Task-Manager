create function box_add(box, point) returns box
    language internal
as
$$box_add$$;

comment on function box_add(box, point) is 'implementation of + operator';

